# CHE-SERIES — Respiratory Chemistry

Interactive Streamlit chemistry project with a 3D molecule viewer and educational structure analysis.

## Deploy
1. Upload `app.py` and `requirements.txt` to your GitHub repository.
2. In Streamlit Community Cloud, select `app.py` as the main file.
3. The 3D viewer loads Three.js from a CDN, so the deployed app needs internet access.
